<?php
//customer route
require __DIR__ . '/Controllers/kai_db.php';