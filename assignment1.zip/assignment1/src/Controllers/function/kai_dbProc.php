<?php
//get all customers
function getAllCustomer($db)
{
$sql = 'Select c.first_name, c.last_name, c.dob, c.driver_license_number, c.email, c.phone FROM customer c ';
$stmt = $db->prepare ($sql);
$stmt ->execute();
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


//get customer by id
function getCustomer($db, $customerId)
{
$sql = 'Select c.first_name, c.last_name, c.dob, c.driver_license_number, c.email, c.phone FROM customer c';
$sql .= ' Where c.id = :id';
$stmt = $db->prepare ($sql);
$id = (int) $customerId;
$stmt->bindParam(':id', $id, PDO::PARAM_INT);
$stmt ->execute(); 
return $stmt->fetchAll(PDO::FETCH_ASSOC);
}


//add new customer
function createCustomer($db, $form_data) {
    $sql = 'Insert into customer (first_name, last_name, dob, driver_license_number, email, phone) ';
    $sql .= 'values (:first_name, :last_name, :dob, :driver_license_number, :email, :phone)';
    $stmt = $db->prepare ($sql);
    $stmt->bindParam(':first_name', $form_data['first_name']);
    $stmt->bindParam(':last_name', $form_data['last_name']);
    $stmt->bindParam(':dob', $form_data['dob']);
    $stmt->bindParam(':driver_license_number', $form_data['driver_license_number']);
    $stmt->bindParam(':email', ($form_data['email']));
    $stmt->bindParam(':phone',($form_data['phone']));
    $stmt->execute();
    return $db->lastInsertID();//insert last number.. continue
    }


//delete customer by id
function deleteCustomer($db,$customerId) {
    $sql = ' Delete from customer where id = :id';
    $stmt = $db->prepare($sql);
    $id = (int)$customerId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    }

    //update customer by id
    function updateCustomer($db,$form_dat,$customerId) {
    $sql = 'UPDATE customer SET first_name = :first_name , last_name = :last_name ,
    dob = :dob , driver_license_number = :driver_license_number , email = :email , phone = :phone ';
    $sql .=' WHERE id = :id';
    $stmt = $db->prepare ($sql);
    $id = (int)$customerId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':first_name', $form_dat['first_name']);
    $stmt->bindParam(':last_name', $form_dat['last_name']);
    $stmt->bindParam(':dob', $form_dat['dob']);
    $stmt->bindParam(':driver_license_number',$form_dat['driver_license_number']);
    $stmt->bindParam(':email', $form_dat['email']);
    $stmt->bindParam(':phone', $form_dat['phone']);
    $stmt->execute();
    }